package com.JavaAssesment.dao;

import  com.JavaAssesment.pojo.Customer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import com.JavaAssesment.dbutil.DataBase;

public class Customers {

String getseq()
{
String id="";
try
{
Connection con=DataBase.getConnection();
String sql="";
sql="select lpad(cust_id_app.nextval,3,'0') from dual";
PreparedStatement statement=con.prepareStatement(sql);
ResultSet r=statement.executeQuery();
if(r.next())
{
id=r.getString(1);
}

}
catch(Exception e){
e.printStackTrace();
}
return id;
}

public void insertData(Customer cust){
String cuid;
String seq;
seq=getseq();
try{
Connection con=DataBase.getConnection();
String sql="insert into  customers values(?,?,?,?) ";
char[] fname=cust.getCustomer_Fname().toCharArray();
char[] lname=cust.getCustomer_Lname().toCharArray();

cuid=""+fname[0]+fname[1]+lname[0]+lname[1]+seq;

PreparedStatement statement=con.prepareStatement(sql);
statement.setString(1,cuid);
statement.setString(2, cust.getCustomer_Fname());
statement.setString(3,cust.getCustomer_Lname());
statement.setString(4,cust.getAddress());

int res=statement.executeUpdate();
if(res>0)
{
System.out.println("values inserted");
}
}
catch (Exception e){
e.printStackTrace();}
}

}