package com.JavaAssesment.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;

public class DataBase {
public static Connection getConnection(){

try{

Class.forName("oracle.jdbc.OracleDriver");
Connection con= DriverManager.getConnection("jdbc:oracle:thin:@127.0.0.1:1521:orcl","dxc","pass");

return con;
}
catch (Exception e) {
e.printStackTrace();
return null;
}
}
}
