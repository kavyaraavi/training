package com.JavaAssesment.pojo;

public class Customer {

String Customer_Fname;
String Customer_Lname;
String Address;

public String getCustomer_Fname() {
return Customer_Fname;
}
public void setCustomer_Fname(String customer_Fname) {
Customer_Fname = customer_Fname;
}
public String getCustomer_Lname() {
return Customer_Lname;
}
public void setCustomer_Lname(String customer_Lname) {
Customer_Lname = customer_Lname;
}
public String getAddress() {
return Address;
}
public void setAddress(String address) {
Address = address;
}


@Override
public String toString() {
return   " Customer First name : " + getCustomer_Fname()
+ " Customer lastname : " + getCustomer_Lname()
+ "  Address : " + getAddress();
}

}
