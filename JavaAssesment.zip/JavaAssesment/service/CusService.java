package com.JavaAssesment.service;
import com.JavaAssesment.pojo.Customer;
import com.JavaAssesment.dao.Customers;

import java.io.BufferedReader;
import java.io.*;


public class CusService {

public static void main(String[] args)throws IOException {
Customer customer=new Customer();
Customers Dao=new Customers();
String fname="virat";
String lname="Kohli";
String address="Chennai";
customer.setCustomer_Fname(fname);
customer.setCustomer_Lname(lname);
customer.setAddress(address);

Dao.insertData(customer);




}

}